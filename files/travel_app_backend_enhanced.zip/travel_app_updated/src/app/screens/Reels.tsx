import { useState, useRef, useEffect, useCallback } from "react";
import { useNavigate } from "react-router";
import {
  Heart, MessageCircle, Share2, Bookmark, MapPin, Play, Volume2, VolumeX,
  ArrowLeft, MoreHorizontal, Star, Send, X, Calendar, Upload, Plus, Camera, Check,
} from "lucide-react";
import { allGuides } from "../data/guides";
import { useAuth, UserReel } from "../context/AuthContext";

// ─── Static seed reels (shown below user-uploaded) ───────────────────────────
type StaticReel = {
  id: number;
  image: string;
  guideId: number;
  location: string;
  description: string;
  likes: number;
  comments: number;
  shares: number;
  savedDefault: boolean;
  likedDefault: boolean;
  tags: string[];
};

const STATIC_REELS: StaticReel[] = [
  { id: 1, guideId: 3, image: "https://images.unsplash.com/photo-1730385835399-4d0f24898919?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Tokyo, Japan", description: "Hidden gem: The secret ramen alley that only locals know about 🍜 Come with me for a late night adventure through Shinjuku's neon-lit streets!", likes: 2847, comments: 134, shares: 89, savedDefault: false, likedDefault: false, tags: ["#tokyo", "#nightlife", "#hiddengems", "#foodie"] },
  { id: 2, guideId: 6, image: "https://images.unsplash.com/photo-1662128406983-e9c949797f11?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Barcelona, Spain", description: "Gaudí's masterpiece like you've never seen it 🌈 I'll take you to the secret sunrise spot completely empty of tourists!", likes: 5213, comments: 287, shares: 342, savedDefault: true, likedDefault: true, tags: ["#barcelona", "#gaudi", "#architecture", "#sunrise"] },
  { id: 3, guideId: 2, image: "https://images.unsplash.com/photo-1679161058888-0f0dc825e8e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Rome, Italy", description: "The real Colosseum experience — no crowds, no rush 🏛️ The early morning light hitting the ancient stones is absolutely breathtaking.", likes: 3654, comments: 198, shares: 215, savedDefault: false, likedDefault: false, tags: ["#rome", "#colosseum", "#history"] },
  { id: 4, guideId: 1, image: "https://images.unsplash.com/photo-1758346971333-c6945f490e06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Paris, France", description: "Sunday morning at Marché d'Aligre — the city's best-kept secret market 🥐🌹", likes: 6891, comments: 415, shares: 523, savedDefault: true, likedDefault: true, tags: ["#paris", "#market", "#sunday"] },
  { id: 5, guideId: 4, image: "https://images.unsplash.com/photo-1647868044625-5637ff8abd1e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "London, UK", description: "Portobello Road on a Saturday — antique treasure hunting with a local 🎸", likes: 4127, comments: 223, shares: 178, savedDefault: false, likedDefault: false, tags: ["#london", "#portobello", "#vintage"] },
  { id: 6, guideId: 5, image: "https://images.unsplash.com/photo-1636682489073-125e6855a665?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "New York, USA", description: "This rooftop bar has zero tourists and the best view of Manhattan 🗽", likes: 7543, comments: 512, shares: 634, savedDefault: false, likedDefault: false, tags: ["#newyork", "#brooklyn", "#nyc"] },
  { id: 7, guideId: 3, image: "https://images.unsplash.com/photo-1649957866905-bef01af303da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Kyoto, Japan", description: "Cherry blossom season at a temple with zero tourists 🌸 Secret timing & hidden path!", likes: 9832, comments: 701, shares: 892, savedDefault: true, likedDefault: false, tags: ["#kyoto", "#sakura", "#japan"] },
  { id: 8, guideId: 6, image: "https://images.unsplash.com/photo-1770359646967-1d008a71e42e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Barcelona, Spain", description: "La Boqueria is overrated — THIS is where Barcelonans actually buy their ingredients 🍅", likes: 3201, comments: 167, shares: 245, savedDefault: false, likedDefault: false, tags: ["#barcelona", "#market", "#food"] },
  { id: 9, guideId: 1, image: "https://images.unsplash.com/photo-1720988583730-1191f37e5fcd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Paris, France", description: "The Eiffel Tower at 5am — just me, a coffee, and absolute magic ✨", likes: 11230, comments: 834, shares: 1102, savedDefault: false, likedDefault: true, tags: ["#paris", "#eiffeltower", "#dawn"] },
  { id: 10, guideId: 2, image: "https://images.unsplash.com/photo-1629212093584-6e1769fb1598?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080", location: "Istanbul, Turkey", description: "The Grand Bazaar through a local's eyes 🕌✨ 4,000 shops — I know which ones have the real deals!", likes: 4127, comments: 223, shares: 178, savedDefault: false, likedDefault: false, tags: ["#istanbul", "#grandbazaar", "#culture"] },
];

function formatCount(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

// ─── Upload Modal ─────────────────────────────────────────────────────────────
function UploadModal({ onClose, onUpload }: { onClose: () => void; onUpload: (data: { imageDataUrl: string; location: string; description: string; tags: string[] }) => void }) {
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (e) => setImageDataUrl(e.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, []);

  const handleSubmit = () => {
    if (!imageDataUrl || !location || !description) return;
    const tags = tagsInput.split(" ").filter((t) => t.trim()).map((t) => t.startsWith("#") ? t : `#${t}`);
    onUpload({ imageDataUrl, location, description, tags });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-white">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-12 pb-4 border-b border-border">
        <button onClick={onClose} className="w-9 h-9 bg-[#FFF8F0] rounded-full flex items-center justify-center">
          <X className="w-5 h-5 text-[#1E3A5F]" />
        </button>
        <h2 className="font-bold text-[#1E3A5F] text-lg">Share a Reel</h2>
        <button
          onClick={handleSubmit}
          disabled={!imageDataUrl || !location || !description}
          className="px-4 py-2 bg-[#E07856] text-white rounded-2xl font-semibold text-sm disabled:opacity-40"
        >
          Share
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5">
        {/* Image upload area */}
        <div
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative rounded-3xl overflow-hidden cursor-pointer transition-all ${isDragging ? "ring-2 ring-[#E07856]" : ""}`}
          style={{ aspectRatio: "9/16", maxHeight: 360 }}
        >
          {imageDataUrl ? (
            <>
              <img src={imageDataUrl} alt="Preview" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                <div className="bg-white/90 rounded-2xl px-4 py-2 flex items-center gap-2">
                  <Camera className="w-4 h-4 text-[#1E3A5F]" />
                  <span className="text-[#1E3A5F] text-sm font-semibold">Change photo</span>
                </div>
              </div>
            </>
          ) : (
            <div className={`w-full h-full flex flex-col items-center justify-center gap-3 border-2 border-dashed rounded-3xl transition-colors ${isDragging ? "border-[#E07856] bg-[#FFF8F0]" : "border-[#E5E7EB] bg-[#F9FAFB]"}`}>
              <div className="w-16 h-16 bg-[#FFF8F0] rounded-full flex items-center justify-center">
                <Upload className="w-7 h-7 text-[#E07856]" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-[#1E3A5F]">Upload a photo</p>
                <p className="text-sm text-[#6B7C93] mt-1">Tap to select or drag & drop</p>
                <p className="text-xs text-[#B0BAC4] mt-1">JPG, PNG, WEBP</p>
              </div>
            </div>
          )}
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) processFile(f); }} />

        {/* Location */}
        <div>
          <label className="block text-[#1E3A5F] text-sm font-semibold mb-1.5">📍 Location</label>
          <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="e.g. Paris, France" className="w-full px-4 py-3 bg-[#FFF8F0] border border-[#E5E7EB] rounded-2xl text-[#1E3A5F] text-sm placeholder:text-[#B0BAC4] outline-none focus:border-[#E07856]" />
        </div>

        {/* Description */}
        <div>
          <label className="block text-[#1E3A5F] text-sm font-semibold mb-1.5">✏️ Caption</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Share what makes this place special..." rows={3} className="w-full px-4 py-3 bg-[#FFF8F0] border border-[#E5E7EB] rounded-2xl text-[#1E3A5F] text-sm placeholder:text-[#B0BAC4] outline-none resize-none focus:border-[#E07856]" />
          <p className="text-xs text-[#B0BAC4] mt-1">{description.length}/200</p>
        </div>

        {/* Tags */}
        <div>
          <label className="block text-[#1E3A5F] text-sm font-semibold mb-1.5"># Tags</label>
          <input value={tagsInput} onChange={(e) => setTagsInput(e.target.value)} placeholder="#travel #hidden #adventure" className="w-full px-4 py-3 bg-[#FFF8F0] border border-[#E5E7EB] rounded-2xl text-[#1E3A5F] text-sm placeholder:text-[#B0BAC4] outline-none focus:border-[#E07856]" />
          <p className="text-xs text-[#6B7C93] mt-1">Separate with spaces</p>
        </div>
      </div>
    </div>
  );
}

// ─── Main Reels Screen ────────────────────────────────────────────────────────
export function Reels() {
  const navigate = useNavigate();
  const { user, userReels, uploadReel, toggleReelLike, toggleReelSave } = useAuth();

  const [likedStatic, setLikedStatic] = useState<Set<number>>(
    new Set(STATIC_REELS.filter((r) => r.likedDefault).map((r) => r.id))
  );
  const [savedStatic, setSavedStatic] = useState<Set<number>>(
    new Set(STATIC_REELS.filter((r) => r.savedDefault).map((r) => r.id))
  );
  const [muted, setMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [contactSheet, setContactSheet] = useState<number | null>(null);
  const [shareMsg, setShareMsg] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showUpload, setShowUpload] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Merge: user-uploaded come first
  type DisplayReel =
    | { type: "user"; data: UserReel }
    | { type: "static"; data: StaticReel };

  const allReels: DisplayReel[] = [
    ...userReels.map((r): DisplayReel => ({ type: "user", data: r })),
    ...STATIC_REELS.map((r): DisplayReel => ({ type: "static", data: r })),
  ];

  const handleScroll = () => {
    if (!containerRef.current) return;
    const idx = Math.round(containerRef.current.scrollTop / containerRef.current.clientHeight);
    setCurrentIndex(idx);
  };

  const handleUpload = (data: { imageDataUrl: string; location: string; description: string; tags: string[] }) => {
    uploadReel(data);
    setUploadSuccess(true);
    setTimeout(() => setUploadSuccess(false), 3000);
  };

  const contactGuide = allGuides.find((g) => g.id === contactSheet);

  if (showUpload) {
    return <UploadModal onClose={() => setShowUpload(false)} onUpload={handleUpload} />;
  }

  return (
    <div className="fixed inset-0 bg-black overflow-hidden">
      {/* Upload success toast */}
      {uploadSuccess && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-[#4CAF50] text-white px-5 py-3 rounded-2xl flex items-center gap-2 shadow-xl">
          <Check className="w-4 h-4" />
          <span className="text-sm font-semibold">Reel shared!</span>
        </div>
      )}

      {/* Scroll container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="h-full overflow-y-scroll snap-y snap-mandatory"
        style={{ scrollbarWidth: "none" }}
      >
        {allReels.map((item, index) => {
          const isUser = item.type === "user";

          if (isUser) {
            const reel = item.data as UserReel;
            const isLiked = reel.likedByEmails.includes(user?.email || "");
            const isSaved = reel.savedByEmails.includes(user?.email || "");

            return (
              <div key={reel.id} className="relative h-screen w-full snap-start snap-always">
                <img src={reel.imageDataUrl} alt={reel.location} className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/30" />

                {/* Top Bar */}
                <div className="absolute top-0 left-0 right-0 pt-12 px-4 flex items-center justify-between z-20">
                  <button onClick={() => navigate("/home")} className="w-10 h-10 bg-black/30 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <ArrowLeft className="w-5 h-5 text-white" />
                  </button>
                  <div className="flex items-center gap-1">
                    {allReels.map((_, i) => (
                      <div key={i} className={`rounded-full transition-all ${i === currentIndex ? "w-5 h-1 bg-white" : "w-1.5 h-1 bg-white/40"}`} />
                    ))}
                  </div>
                  <button onClick={() => setShowUpload(true)} className="w-10 h-10 bg-[#E07856] backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Plus className="w-5 h-5 text-white" />
                  </button>
                </div>

                {/* Right Actions */}
                <div className="absolute right-4 bottom-52 flex flex-col items-center gap-5 z-20">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full border-2 border-white bg-[#E07856] flex items-center justify-center overflow-hidden">
                      {reel.userAvatar ? <img src={reel.userAvatar} alt="" className="w-full h-full object-cover" /> : <span className="text-white font-bold text-lg">{reel.userName[0]}</span>}
                    </div>
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-5 h-5 bg-[#E07856] rounded-full flex items-center justify-center">
                      <span className="text-white font-bold" style={{ fontSize: "11px" }}>✓</span>
                    </div>
                  </div>
                  <button className="flex flex-col items-center gap-1 z-30" onClick={(e) => { e.stopPropagation(); toggleReelLike(reel.id); }}>
                    <Heart className={`w-7 h-7 transition-all ${isLiked ? "fill-[#E07856] text-[#E07856] scale-110" : "text-white"}`} />
                    <span className="text-white text-xs font-semibold">{formatCount(reel.likes + (isLiked ? 1 : 0))}</span>
                  </button>
                  <button className="flex flex-col items-center gap-1 z-30">
                    <MessageCircle className="w-7 h-7 text-white" />
                    <span className="text-white text-xs font-semibold">{formatCount(reel.comments)}</span>
                  </button>
                  <button className="flex flex-col items-center gap-1 z-30">
                    <Share2 className="w-7 h-7 text-white" />
                    <span className="text-white text-xs font-semibold">{formatCount(reel.shares)}</span>
                  </button>
                  <button className="flex flex-col items-center gap-1 z-30" onClick={(e) => { e.stopPropagation(); toggleReelSave(reel.id); }}>
                    <Bookmark className={`w-7 h-7 transition-colors ${isSaved ? "fill-[#FF8C42] text-[#FF8C42]" : "text-white"}`} />
                  </button>
                  <button className="w-10 h-10 bg-black/30 rounded-full flex items-center justify-center z-30" onClick={(e) => { e.stopPropagation(); setMuted((m) => !m); }}>
                    {muted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
                  </button>
                </div>

                {/* Bottom Info */}
                <div className="absolute bottom-0 left-0 right-16 p-5 pb-10 z-20">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white font-semibold">@{reel.userName.toLowerCase().replace(" ", "_")}</span>
                    <div className="bg-[#E07856]/80 rounded-full px-2 py-0.5 text-white text-xs">Traveler</div>
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    <MapPin className="w-4 h-4 text-[#FF8C42]" />
                    <span className="text-[#FF8C42] text-sm font-semibold">{reel.location}</span>
                  </div>
                  <p className="text-white text-sm leading-relaxed mb-2 line-clamp-2">{reel.description}</p>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {reel.tags.map((tag) => <span key={tag} className="text-[#FF8C42]/80 text-xs">{tag}</span>)}
                  </div>
                </div>
              </div>
            );
          }

          // Static reel
          const reel = item.data as StaticReel;
          const guide = allGuides.find((g) => g.id === reel.guideId)!;
          const isLiked = likedStatic.has(reel.id);
          const isSaved = savedStatic.has(reel.id);
          const likeCount = reel.likes + (isLiked && !reel.likedDefault ? 1 : !isLiked && reel.likedDefault ? -1 : 0);

          return (
            <div key={reel.id} className="relative h-screen w-full snap-start snap-always flex-shrink-0">
              <img src={reel.image} alt={reel.location} className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/30" />

              {/* Top Bar */}
              <div className="absolute top-0 left-0 right-0 pt-12 px-4 flex items-center justify-between z-20">
                <button onClick={() => navigate("/home")} className="w-10 h-10 bg-black/30 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <ArrowLeft className="w-5 h-5 text-white" />
                </button>
                <div className="flex items-center gap-1">
                  {allReels.map((_, i) => (
                    <div key={i} className={`rounded-full transition-all ${i === currentIndex ? "w-5 h-1 bg-white" : "w-1.5 h-1 bg-white/40"}`} />
                  ))}
                </div>
                <button onClick={() => setShowUpload(true)} className="w-10 h-10 bg-[#E07856] rounded-full flex items-center justify-center">
                  <Plus className="w-5 h-5 text-white" />
                </button>
              </div>

              <button className="absolute inset-0 z-10" onClick={() => setIsPlaying((p) => !p)}>
                {!isPlaying && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-20 h-20 bg-black/40 rounded-full flex items-center justify-center">
                      <Play className="w-10 h-10 text-white fill-white ml-1" />
                    </div>
                  </div>
                )}
              </button>

              {/* Right Side Actions */}
              <div className="absolute right-4 bottom-52 flex flex-col items-center gap-5 z-20">
                <button onClick={() => navigate(`/guide/${guide.id}`)} className="relative">
                  <img src={guide.avatar} alt={guide.name} className="w-12 h-12 rounded-full border-2 border-white object-cover" />
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-5 h-5 bg-[#E07856] rounded-full flex items-center justify-center">
                    <span className="text-white font-bold" style={{ fontSize: "11px" }}>+</span>
                  </div>
                </button>
                <button className="flex flex-col items-center gap-1 z-30" onClick={(e) => { e.stopPropagation(); setLikedStatic((prev) => { const n = new Set(prev); if (n.has(reel.id)) n.delete(reel.id); else n.add(reel.id); return n; }); }}>
                  <Heart className={`w-7 h-7 transition-all ${isLiked ? "fill-[#E07856] text-[#E07856] scale-110" : "text-white"}`} />
                  <span className="text-white text-xs font-semibold">{formatCount(likeCount)}</span>
                </button>
                <button className="flex flex-col items-center gap-1 z-30" onClick={(e) => { e.stopPropagation(); setContactSheet(reel.guideId); }}>
                  <MessageCircle className="w-7 h-7 text-white" />
                  <span className="text-white text-xs font-semibold">{formatCount(reel.comments)}</span>
                </button>
                <button className="flex flex-col items-center gap-1 z-30" onClick={(e) => e.stopPropagation()}>
                  <Share2 className="w-7 h-7 text-white" />
                  <span className="text-white text-xs font-semibold">{formatCount(reel.shares)}</span>
                </button>
                <button className="flex flex-col items-center gap-1 z-30" onClick={(e) => { e.stopPropagation(); setSavedStatic((prev) => { const n = new Set(prev); if (n.has(reel.id)) n.delete(reel.id); else n.add(reel.id); return n; }); }}>
                  <Bookmark className={`w-7 h-7 transition-colors ${isSaved ? "fill-[#FF8C42] text-[#FF8C42]" : "text-white"}`} />
                </button>
                <button className="w-10 h-10 bg-black/30 rounded-full flex items-center justify-center z-30" onClick={(e) => { e.stopPropagation(); setMuted((m) => !m); }}>
                  {muted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
                </button>
              </div>

              {/* Bottom Info */}
              <div className="absolute bottom-0 left-0 right-16 p-5 pb-10 z-20">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-white font-semibold">@{guide.name.toLowerCase().replace(" ", "_")}</span>
                  {guide.verified && <div className="w-4 h-4 bg-[#4CAF50] rounded-full flex items-center justify-center"><span className="text-white text-xs">✓</span></div>}
                  <div className="flex items-center gap-1 bg-black/30 backdrop-blur-sm rounded-full px-2 py-0.5">
                    <Star className="w-3 h-3 fill-[#FF8C42] text-[#FF8C42]" />
                    <span className="text-white text-xs">{guide.rating}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 mb-2">
                  <MapPin className="w-4 h-4 text-[#FF8C42]" />
                  <span className="text-[#FF8C42] text-sm font-semibold">{reel.location}</span>
                </div>
                <p className="text-white text-sm leading-relaxed mb-2 line-clamp-2">{reel.description}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {reel.tags.map((tag) => <span key={tag} className="text-[#FF8C42]/80 text-xs">{tag}</span>)}
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setContactSheet(reel.guideId)} className="flex-1 h-10 bg-white/20 backdrop-blur-sm border border-white/40 rounded-2xl text-white font-semibold text-sm flex items-center justify-center gap-1.5">
                    <MessageCircle className="w-4 h-4" /> Contact
                  </button>
                  <button onClick={() => navigate(`/booking/${reel.guideId}`)} className="flex-1 h-10 bg-[#E07856] rounded-2xl text-white font-semibold text-sm flex items-center justify-center gap-1.5">
                    <Calendar className="w-4 h-4" /> Book Now
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Contact Bottom Sheet */}
      {contactSheet !== null && contactGuide && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/60" onClick={() => setContactSheet(null)} />
          <div className="relative bg-white rounded-t-3xl p-6 pb-10">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img src={contactGuide.avatar} alt={contactGuide.name} className="w-12 h-12 rounded-full object-cover" />
                  {contactGuide.available && <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#4CAF50] rounded-full border-2 border-white" />}
                </div>
                <div>
                  <p className="font-semibold text-[#1E3A5F]">{contactGuide.name}</p>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 fill-[#FF8C42] text-[#FF8C42]" />
                    <span className="text-xs text-[#6B7C93]">{contactGuide.rating} · {contactGuide.city}</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setContactSheet(null)} className="w-8 h-8 bg-[#FFF8F0] rounded-full flex items-center justify-center">
                <X className="w-4 h-4 text-[#6B7C93]" />
              </button>
            </div>
            <p className="text-sm text-[#6B7C93] mb-3">Send a quick message to {contactGuide.name.split(" ")[0]}</p>
            <div className="flex gap-2 mb-4">
              <input value={shareMsg} onChange={(e) => setShareMsg(e.target.value)} placeholder={`Hi ${contactGuide.name.split(" ")[0]}! I saw your reel...`} className="flex-1 h-11 px-4 rounded-2xl bg-[#FFF8F0] border border-border outline-none text-[#1E3A5F] text-sm placeholder:text-[#6B7C93]" />
              <button onClick={() => { navigate(`/messages?guideId=${contactGuide.id}`); setContactSheet(null); }} className="w-11 h-11 bg-[#E07856] rounded-2xl flex items-center justify-center">
                <Send className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="flex flex-wrap gap-2 mb-5">
              {[`Hi ${contactGuide.name.split(" ")[0]}! I loved your reel 😍`, "What are your rates?", "Are you available this week?", "Tell me more about your tours!"].map((q) => (
                <button key={q} onClick={() => setShareMsg(q)} className="px-3 py-1.5 bg-[#FFF8F0] border border-[#E07856]/30 text-[#E07856] rounded-full text-xs font-medium">{q}</button>
              ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => navigate(`/guide/${contactGuide.id}`)} className="flex-1 h-12 border-2 border-[#1E3A5F] text-[#1E3A5F] rounded-2xl font-semibold">View Profile</button>
              <button onClick={() => navigate(`/booking/${contactGuide.id}`)} className="flex-1 h-12 bg-[#E07856] text-white rounded-2xl font-semibold">Book Now</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
