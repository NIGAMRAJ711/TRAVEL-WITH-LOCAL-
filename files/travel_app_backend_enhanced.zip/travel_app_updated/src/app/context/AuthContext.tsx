import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type NotificationType = "booking" | "message" | "review" | "promo" | "system";

export type AppNotification = {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  time: string;
  read: boolean;
  guideId?: number;
  avatar?: string;
};

export type MarkedPlace = {
  id: string;
  name: string;
  city: string;
  x: number;
  y: number;
  note: string;
  color: string;
  emoji?: string;
};

export type BookingRecord = {
  id: string;
  guideId: number;
  guideName: string;
  guideAvatar: string;
  city: string;
  date: string;
  time: string;
  duration: string;
  price: number;
  status: "confirmed" | "pending" | "completed" | "cancelled";
  tourType: string;
};

export type ChatMessage = {
  id: string;
  from: "user" | "guide";
  text: string;
  time: string;
  read: boolean;
  createdAt: number;
};

export type Conversation = {
  guideId: number;
  messages: ChatMessage[];
  unread: number;
  lastUpdated: number;
};

export type UserReel = {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  userAvatar: string;
  imageDataUrl: string;
  location: string;
  description: string;
  tags: string[];
  likes: number;
  comments: number;
  shares: number;
  likedByEmails: string[];
  savedByEmails: string[];
  createdAt: number;
};

export type User = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: "traveler" | "guide";
  savedGuides: number[];
  markedPlaces: MarkedPlace[];
  notifications: AppNotification[];
  bookings: BookingRecord[];
  conversations: Conversation[];
  toursBooked: number;
  citiesVisited: number;
  reviewsGiven: number;
  joinDate: string;
  bio: string;
  city: string;
  phone: string;
  website: string;
};

type StoredAccount = {
  user: User;
  password: string;
};

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string, role: "traveler" | "guide") => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  toggleRole: () => void;
  saveGuide: (id: number) => void;
  unsaveGuide: (id: number) => void;
  markPlace: (place: Omit<MarkedPlace, "id">) => void;
  unmarkPlace: (id: string) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  clearAllNotifications: () => void;
  addBooking: (booking: Omit<BookingRecord, "id">) => void;
  unreadNotificationCount: number;
  getConversation: (guideId: number) => Conversation | undefined;
  sendMessage: (guideId: number, text: string, guideName: string, guideAvatar: string, guideCity: string) => void;
  markConversationRead: (guideId: number) => void;
  totalUnreadMessages: number;
  userReels: UserReel[];
  uploadReel: (reel: Omit<UserReel, "id" | "userId" | "userEmail" | "userName" | "userAvatar" | "likes" | "comments" | "shares" | "likedByEmails" | "savedByEmails" | "createdAt">) => void;
  toggleReelLike: (reelId: string) => void;
  toggleReelSave: (reelId: string) => void;
};

const AuthContext = createContext<AuthContextType | null>(null);

const STORAGE_KEYS = {
  SESSION: "ll_session",
  ACCOUNTS: "ll_accounts",
  REELS: "ll_reels_global",
};

const AUTO_REPLIES = [
  "That sounds great! Let me check my availability for you 📅",
  "Perfect! I have some amazing spots in mind for exactly that experience 🗺️",
  "Wonderful choice! I'll put together a custom itinerary shortly.",
  "Absolutely! I've done this tour many times and it never disappoints 😊",
  "Great question! Early morning is the best time to avoid crowds.",
  "I love your enthusiasm! Let me know your preferred dates and I'll confirm.",
  "Yes, that's one of my favourite routes! You're going to love it ✨",
  "Sure thing! I can also arrange private transport if needed.",
];

function randomReply() {
  return AUTO_REPLIES[Math.floor(Math.random() * AUTO_REPLIES.length)];
}

const DEFAULT_NOTIFICATIONS: AppNotification[] = [
  { id: "n1", type: "booking", title: "Booking Confirmed! 🎉", body: "Your tour with Sophie Laurent in Paris on April 5th is confirmed.", time: "2 hours ago", read: false, guideId: 1, avatar: "https://images.unsplash.com/photo-1514189672269-0e46fbfd9260?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200" },
  { id: "n2", type: "message", title: "New message from Marco Rossi", body: "\"The Colosseum at dawn is truly magical — you'll have the arena to yourself!\"", time: "5 hours ago", read: false, guideId: 2, avatar: "https://images.unsplash.com/photo-1591953996491-ea0d5ff3db59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200" },
  { id: "n3", type: "review", title: "Review Request", body: "How was your tour with Emma Wilson in London? Share your experience!", time: "1 day ago", read: true, guideId: 4, avatar: "https://images.unsplash.com/photo-1759572987527-ee1692f1aab8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200" },
  { id: "n4", type: "promo", title: "🌟 Special Offer", body: "Get 20% off your next booking in Tokyo! Use code TOKYO20.", time: "2 days ago", read: true },
  { id: "n5", type: "system", title: "Welcome to LocalLens!", body: "Your account is verified. Start exploring local guides around the world.", time: "3 days ago", read: true },
];

const DEFAULT_BOOKINGS: BookingRecord[] = [
  { id: "b1", guideId: 4, guideName: "Emma Wilson", guideAvatar: "https://images.unsplash.com/photo-1759572987527-ee1692f1aab8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200", city: "London, UK", date: "March 22, 2026", time: "10:00 AM", duration: "Full Day", price: 210, status: "completed", tourType: "Street Art & Coffee" },
  { id: "b2", guideId: 1, guideName: "Sophie Laurent", guideAvatar: "https://images.unsplash.com/photo-1514189672269-0e46fbfd9260?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200", city: "Paris, France", date: "April 5, 2026", time: "9:00 AM", duration: "Half Day", price: 120, status: "confirmed", tourType: "Food & Hidden Gems" },
  { id: "b3", guideId: 2, guideName: "Marco Rossi", guideAvatar: "https://images.unsplash.com/photo-1591953996491-ea0d5ff3db59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200", city: "Rome, Italy", date: "April 12, 2026", time: "6:30 AM", duration: "Half Day", price: 135, status: "pending", tourType: "Dawn Colosseum Tour" },
];

const DEFAULT_CONVERSATIONS: Conversation[] = [
  {
    guideId: 1, unread: 2, lastUpdated: Date.now() - 1000 * 60 * 30,
    messages: [
      { id: "m1", from: "guide", text: "Hi! Thanks for your interest. I'd love to show you around Paris! What areas are you most interested in?", time: "10:30 AM", read: true, createdAt: Date.now() - 1000 * 60 * 90 },
      { id: "m2", from: "user", text: "Hi Sophie! I'm really interested in the local food scene and hidden cafés.", time: "10:32 AM", read: true, createdAt: Date.now() - 1000 * 60 * 88 },
      { id: "m3", from: "guide", text: "Perfect! I know all the best spots. I can take you to some amazing local markets and cafés that tourists never find 😊", time: "10:33 AM", read: true, createdAt: Date.now() - 1000 * 60 * 87 },
      { id: "m4", from: "user", text: "That sounds amazing! What dates are you available in April?", time: "11:05 AM", read: true, createdAt: Date.now() - 1000 * 60 * 85 },
      { id: "m5", from: "guide", text: "I'm free April 5th, 8th, and 12th! Morning slots work best for the markets ☀️", time: "11:08 AM", read: false, createdAt: Date.now() - 1000 * 60 * 32 },
      { id: "m6", from: "guide", text: "Also, I have a special food walk designed for small groups. Interested?", time: "11:09 AM", read: false, createdAt: Date.now() - 1000 * 60 * 31 },
    ],
  },
  {
    guideId: 2, unread: 0, lastUpdated: Date.now() - 1000 * 60 * 60 * 24,
    messages: [
      { id: "m1", from: "user", text: "Hi Marco! I saw your profile and I'm visiting Rome next month.", time: "Yesterday", read: true, createdAt: Date.now() - 1000 * 60 * 60 * 25 },
      { id: "m2", from: "guide", text: "Benvenuto! Rome is stunning in April 🏛️", time: "Yesterday", read: true, createdAt: Date.now() - 1000 * 60 * 60 * 24 },
      { id: "m3", from: "user", text: "I'm particularly interested in the early morning Colosseum tour!", time: "Yesterday", read: true, createdAt: Date.now() - 1000 * 60 * 60 * 23 },
      { id: "m4", from: "guide", text: "Great choice! We go just as the sun rises — you'll have the entire arena practically to yourself. Truly magical.", time: "Yesterday", read: true, createdAt: Date.now() - 1000 * 60 * 60 * 22 },
    ],
  },
  {
    guideId: 4, unread: 1, lastUpdated: Date.now() - 1000 * 60 * 60 * 48,
    messages: [
      { id: "m1", from: "guide", text: "Hello! London is absolutely buzzing right now — perfect time to visit!", time: "Mon", read: true, createdAt: Date.now() - 1000 * 60 * 60 * 50 },
      { id: "m2", from: "user", text: "Hey Emma! Yes, I'm planning a trip in mid-April. Your street art tour looks incredible.", time: "Mon", read: true, createdAt: Date.now() - 1000 * 60 * 60 * 49 },
      { id: "m3", from: "guide", text: "You'll love it! Shoreditch has some brand new murals this season. I booked you in for April 14th — does that work? 🎨", time: "Mon", read: false, createdAt: Date.now() - 1000 * 60 * 60 * 48 },
    ],
  },
];

const DEMO_TRAVELER: StoredAccount = {
  password: "traveler123",
  user: {
    id: "demo-traveler", name: "Alex Johnson", email: "traveler@demo.com", avatar: "", role: "traveler",
    savedGuides: [1, 3],
    markedPlaces: [
      { id: "mp1", name: "Eiffel Tower", city: "Paris", x: 48, y: 38, note: "Must visit at sunset!", color: "#E07856" },
      { id: "mp2", name: "Colosseum", city: "Rome", x: 68, y: 55, note: "Book dawn tour", color: "#1E3A5F" },
    ],
    notifications: DEFAULT_NOTIFICATIONS, bookings: DEFAULT_BOOKINGS, conversations: DEFAULT_CONVERSATIONS,
    toursBooked: 12, citiesVisited: 8, reviewsGiven: 15, joinDate: "January 2025",
    bio: "Adventure seeker and travel enthusiast exploring the world one city at a time.",
    city: "San Francisco, USA", phone: "+1 (415) 555-0123", website: "",
  },
};

const DEMO_GUIDE: StoredAccount = {
  password: "guide123",
  user: {
    id: "demo-guide", name: "Sophie Laurent", email: "guide@demo.com",
    avatar: "https://images.unsplash.com/photo-1514189672269-0e46fbfd9260?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200",
    role: "guide", savedGuides: [], markedPlaces: [],
    notifications: [
      { id: "gn1", type: "booking", title: "New Booking Request", body: "Alex Johnson wants to book your Food & Hidden Gems tour on April 5th.", time: "1 hour ago", read: false },
      { id: "gn2", type: "review", title: "New 5-Star Review ⭐", body: "Michael R. left you a 5-star review: \"Sophie was absolutely amazing!\"", time: "3 hours ago", read: false },
    ],
    bookings: [], conversations: [], toursBooked: 0, citiesVisited: 1, reviewsGiven: 0, joinDate: "March 2018",
    bio: "Born and raised in Paris, I've been showing travelers the hidden gems of this beautiful city for 8 years.",
    city: "Paris, France", phone: "+33 1 23 45 67 89", website: "sophieparis.com",
  },
};

function getAccounts(): Record<string, StoredAccount> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    const stored = raw ? JSON.parse(raw) : {};
    if (!stored["traveler@demo.com"]) stored["traveler@demo.com"] = DEMO_TRAVELER;
    if (!stored["guide@demo.com"]) stored["guide@demo.com"] = DEMO_GUIDE;
    for (const key of Object.keys(stored)) {
      if (!stored[key].user.conversations) stored[key].user.conversations = [];
    }
    return stored;
  } catch {
    return { "traveler@demo.com": DEMO_TRAVELER, "guide@demo.com": DEMO_GUIDE };
  }
}

function saveAccounts(accounts: Record<string, StoredAccount>) {
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
}

function getSession(): User | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SESSION);
    const u = raw ? JSON.parse(raw) : null;
    if (u && !u.conversations) u.conversations = [];
    return u;
  } catch { return null; }
}

function saveSession(user: User | null) {
  if (user) localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(user));
  else localStorage.removeItem(STORAGE_KEYS.SESSION);
}

function getGlobalReels(): UserReel[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.REELS);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveGlobalReels(reels: UserReel[]) {
  localStorage.setItem(STORAGE_KEYS.REELS, JSON.stringify(reels));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [userReels, setUserReelsState] = useState<UserReel[]>([]);

  useEffect(() => {
    const session = getSession();
    setUser(session);
    setUserReelsState(getGlobalReels());
    setIsLoading(false);
  }, []);

  const persistUser = (updatedUser: User) => {
    setUser(updatedUser);
    saveSession(updatedUser);
    const accounts = getAccounts();
    if (accounts[updatedUser.email]) {
      accounts[updatedUser.email].user = updatedUser;
      saveAccounts(accounts);
    }
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    await new Promise((r) => setTimeout(r, 600));
    const accounts = getAccounts();
    const account = accounts[email.toLowerCase()];
    if (!account) return { success: false, error: "No account found with this email address." };
    if (account.password !== password) return { success: false, error: "Incorrect password. Please try again." };
    persistUser(account.user);
    setUserReelsState(getGlobalReels());
    return { success: true };
  };

  const register = async (name: string, email: string, password: string, role: "traveler" | "guide"): Promise<{ success: boolean; error?: string }> => {
    await new Promise((r) => setTimeout(r, 800));
    const accounts = getAccounts();
    const lowerEmail = email.toLowerCase();
    if (accounts[lowerEmail]) return { success: false, error: "An account with this email already exists." };
    const newUser: User = {
      id: `user-${Date.now()}`, name, email: lowerEmail, avatar: "", role,
      savedGuides: [], markedPlaces: [],
      notifications: [{ id: "welcome", type: "system", title: `Welcome to LocalLens, ${name.split(" ")[0]}! 🎉`, body: "Your account is ready. Start exploring local guides around the world.", time: "Just now", read: false }],
      bookings: [], conversations: [], toursBooked: 0, citiesVisited: 0, reviewsGiven: 0,
      joinDate: new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" }),
      bio: "", city: "", phone: "", website: "",
    };
    accounts[lowerEmail] = { user: newUser, password };
    saveAccounts(accounts);
    persistUser(newUser);
    return { success: true };
  };

  const logout = () => { setUser(null); saveSession(null); };

  const updateProfile = (data: Partial<User>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    persistUser(updated);
    if (data.email && data.email !== user.email) {
      const accounts = getAccounts();
      accounts[data.email.toLowerCase()] = { ...accounts[user.email], user: updated };
      delete accounts[user.email];
      saveAccounts(accounts);
    }
  };

  const toggleRole = () => { if (!user) return; updateProfile({ role: user.role === "traveler" ? "guide" : "traveler" }); };
  const saveGuide = (id: number) => { if (!user || user.savedGuides.includes(id)) return; updateProfile({ savedGuides: [...user.savedGuides, id] }); };
  const unsaveGuide = (id: number) => { if (!user) return; updateProfile({ savedGuides: user.savedGuides.filter((g) => g !== id) }); };
  const markPlace = (place: Omit<MarkedPlace, "id">) => { if (!user) return; updateProfile({ markedPlaces: [...user.markedPlaces, { ...place, id: `place-${Date.now()}` }] }); };
  const unmarkPlace = (id: string) => { if (!user) return; updateProfile({ markedPlaces: user.markedPlaces.filter((p) => p.id !== id) }); };
  const markNotificationRead = (id: string) => { if (!user) return; updateProfile({ notifications: user.notifications.map((n) => n.id === id ? { ...n, read: true } : n) }); };
  const markAllNotificationsRead = () => { if (!user) return; updateProfile({ notifications: user.notifications.map((n) => ({ ...n, read: true })) }); };
  const clearAllNotifications = () => { if (!user) return; updateProfile({ notifications: [] }); };
  const addBooking = (booking: Omit<BookingRecord, "id">) => {
    if (!user) return;
    updateProfile({ bookings: [{ ...booking, id: `booking-${Date.now()}` }, ...user.bookings], toursBooked: user.toursBooked + 1 });
  };

  const getConversation = (guideId: number) => user?.conversations?.find((c) => c.guideId === guideId);

  const sendMessage = (guideId: number, text: string, guideName: string, guideAvatar: string, guideCity: string) => {
    if (!user) return;
    const conversations = user.conversations || [];
    const existing = conversations.find((c) => c.guideId === guideId);
    const now = Date.now();
    const timeStr = new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    const newMsg: ChatMessage = { id: `msg-${now}`, from: "user", text, time: timeStr, read: true, createdAt: now };

    let updatedConversations: Conversation[];
    if (existing) {
      updatedConversations = conversations.map((c) =>
        c.guideId === guideId ? { ...c, messages: [...c.messages, newMsg], lastUpdated: now } : c
      );
    } else {
      const welcomeMsg: ChatMessage = {
        id: `msg-welcome-${now}`, from: "guide",
        text: `Hi! I'm ${guideName} from ${guideCity}. Thanks for reaching out! I'd love to show you around. What kind of experience are you looking for?`,
        time: timeStr, read: true, createdAt: now - 1,
      };
      updatedConversations = [{ guideId, messages: [welcomeMsg, newMsg], unread: 0, lastUpdated: now }, ...conversations];
    }

    const updatedUser = { ...user, conversations: updatedConversations };
    persistUser(updatedUser);

    setTimeout(() => {
      const freshAccounts = getAccounts();
      const freshUser = freshAccounts[updatedUser.email]?.user;
      if (!freshUser) return;
      const replyNow = Date.now();
      const replyTime = new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
      const replyMsg: ChatMessage = { id: `msg-reply-${replyNow}`, from: "guide", text: randomReply(), time: replyTime, read: false, createdAt: replyNow };
      const freshConvs = freshUser.conversations || [];
      const updatedConvs = freshConvs.map((c) =>
        c.guideId === guideId ? { ...c, messages: [...c.messages, replyMsg], unread: c.unread + 1, lastUpdated: replyNow } : c
      );
      const newNotif: AppNotification = { id: `notif-msg-${replyNow}`, type: "message", title: `New message from ${guideName}`, body: replyMsg.text, time: "Just now", read: false, guideId, avatar: guideAvatar };
      const replyUser = { ...freshUser, conversations: updatedConvs, notifications: [newNotif, ...(freshUser.notifications || [])] };
      freshAccounts[replyUser.email].user = replyUser;
      saveAccounts(freshAccounts);
      saveSession(replyUser);
      setUser(replyUser);
    }, 1500);
  };

  const markConversationRead = (guideId: number) => {
    if (!user) return;
    updateProfile({
      conversations: (user.conversations || []).map((c) =>
        c.guideId === guideId ? { ...c, unread: 0, messages: c.messages.map((m) => ({ ...m, read: true })) } : c
      ),
    });
  };

  const totalUnreadMessages = (user?.conversations || []).reduce((sum, c) => sum + c.unread, 0);

  const uploadReel = (reelData: Omit<UserReel, "id" | "userId" | "userEmail" | "userName" | "userAvatar" | "likes" | "comments" | "shares" | "likedByEmails" | "savedByEmails" | "createdAt">) => {
    if (!user) return;
    const newReel: UserReel = { ...reelData, id: `reel-${Date.now()}`, userId: user.id, userEmail: user.email, userName: user.name, userAvatar: user.avatar, likes: 0, comments: 0, shares: 0, likedByEmails: [], savedByEmails: [], createdAt: Date.now() };
    const updated = [newReel, ...userReels];
    setUserReelsState(updated);
    saveGlobalReels(updated);
  };

  const toggleReelLike = (reelId: string) => {
    if (!user) return;
    const updated = userReels.map((r) => {
      if (r.id !== reelId) return r;
      const liked = r.likedByEmails.includes(user.email);
      return { ...r, likes: liked ? r.likes - 1 : r.likes + 1, likedByEmails: liked ? r.likedByEmails.filter((e) => e !== user.email) : [...r.likedByEmails, user.email] };
    });
    setUserReelsState(updated);
    saveGlobalReels(updated);
  };

  const toggleReelSave = (reelId: string) => {
    if (!user) return;
    const updated = userReels.map((r) => {
      if (r.id !== reelId) return r;
      const saved = r.savedByEmails.includes(user.email);
      return { ...r, savedByEmails: saved ? r.savedByEmails.filter((e) => e !== user.email) : [...r.savedByEmails, user.email] };
    });
    setUserReelsState(updated);
    saveGlobalReels(updated);
  };

  const unreadNotificationCount = user ? user.notifications.filter((n) => !n.read).length : 0;

  return (
    <AuthContext.Provider value={{
      user, isLoading, login, register, logout, updateProfile, toggleRole,
      saveGuide, unsaveGuide, markPlace, unmarkPlace,
      markNotificationRead, markAllNotificationsRead, clearAllNotifications,
      addBooking, unreadNotificationCount,
      getConversation, sendMessage, markConversationRead, totalUnreadMessages,
      userReels, uploadReel, toggleReelLike, toggleReelSave,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
